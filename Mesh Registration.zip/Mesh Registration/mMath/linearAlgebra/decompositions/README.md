General tools for decomposing linear algebra elements.
