function v = vec(M)
% Vectorize column-wise all elements in the input array
% 
% See also: Re1DSpace.vec

v = M(:);

end