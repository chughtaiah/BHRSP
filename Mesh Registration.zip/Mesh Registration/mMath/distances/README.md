Common distance functions for different domains.
