function r = rowsizes(A)

r = A.rsizes;
