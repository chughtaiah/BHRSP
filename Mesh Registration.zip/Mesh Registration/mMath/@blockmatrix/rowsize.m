function r = rowsize(A)

r = A.rsizes(1);
