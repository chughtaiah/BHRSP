function c = ncols(A)

c = length(A.csizes);
