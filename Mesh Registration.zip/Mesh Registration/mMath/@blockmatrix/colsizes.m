function c = colsizes(A)

c = A.csizes;
