function r = nrows(A)

r = length(A.rsizes);
