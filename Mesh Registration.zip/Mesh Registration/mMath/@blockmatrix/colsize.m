function c = colsize(A)

c = A.csizes(1);
