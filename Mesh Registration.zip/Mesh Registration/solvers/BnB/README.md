The code here for BnB is provided by Carl Olsson.
